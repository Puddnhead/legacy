const repositories = [
    {
        name: "tps-cpr-claim-data",
        description: "Data layer library for CPR services, used by both cpr-ingestor and cpr-report-service",
        link: "https://github.com/Lord-of-the-Repos/tps-cpr-claim-data"
    },
    {
        name: "tps-cpr-config-service",
        description: "Exposes REST services for managing client configuraitons",
        link: "https://github.com/Lord-of-the-Repos/tps-cpr-config-service.git"
    },
    {
        name: "tps-cpr-enrichment-service",
        description: "Claim enrichment service (planned to be used for Biosimilarity, Specialty Drug, etc.)",
        link: "https://github.com/Lord-of-the-Repos/tps-cpr-enrichment-service.git"
    },
    {
        name: "tps-cpr-ingester-service",
        description: "Service that ingests claims from upstream services and persists them in the CPR DB",
        link: "https://github.com/Lord-of-the-Repos/tps-cpr-ingester-service"
    },
    {
        name: "tps-cpr-pages",
        description: "Repo for this dashboard",
        link: "https://github.com/Lord-of-the-Repos/tps-cpr-pages"
    },
    {
        name: "tps-cpr-payment-service",
        description: "Service that manages guarantee and passthrough payments to clients",
        link: "https://github.com/Lord-of-the-Repos/tps-cpr-payment-service"
    },
    {
        name: "tps-cpr-report-service",
        description: "Service that generates claim quality exclusion and invoice exclusion reports",
        link: "https://github.com/Lord-of-the-Repos/tps-cpr-report-service"
    },
    {
        name: "tps-cpr-scheduler",
        description: "Scheduler service that posts messages to kafka according to a schedule",
        link: "https://github.com/Lord-of-the-Repos/tps-cpr-scheduler"
    },
    {
        name: "tps-cpr-kafka-archiver",
        description: "This app consumes and persist kafka messages so no messages are lost at the end of the mandatory 7-day retention period.",
        link: "https://github.com/Lord-of-the-Repos/tps-cpr-kafka-archiver"
    },
    {
        name: "tps-cpr-service-provisioning",
        description: "Service definitions for CPR databases, kafka, and object storage",
        link: "https://github.com/Lord-of-the-Repos/tps-cpr-service-provisioning"
    },
    {
        name: "tps-cpr-service-template",
        description: "Template repo for generating new services",
        link: "https://github.com/Lord-of-the-Repos/tps-cpr-service-template.git"
    },
    {
        name: "tps-rebate-cpr-schemas",
        description: "AVRO schemas produced by the CPR team",
        link: "https://github.com/Lord-of-the-Repos/tps-rebate-cpr-schemas"
    },
    {
        name: "tps-rebate-arc-ui",
        description: "Rebate Arc UI",
        link: "https://github.com/Lord-of-the-Repos/tps-rebate-arc-ui"
    },
    {
        name: "tps-boot-common",
        description: "Boot Common",
        link: "https://github.com/Lord-of-the-Repos/tps-boot-common"
    },
    {
        name: "tps-excel-common",
        description: "Library for producing XLSX files",
        link: "https://github.com/Lord-of-the-Repos/tps-excel-common"
    },
    {
        name: "tps-kafka-event-metadata",
        description: "Library for publishing kafka events using the cloudevents spec",
        link: "https://github.com/Lord-of-the-Repos/tps-kafka-event-metadata"
    },
    {
        name: "tps-kafka-common",
        description: "Library for sending kafka messages and providing health checks on kafka",
        link: "https://github.com/Lord-of-the-Repos/tps-kafka-common"
    },
    {
        name: "tps-cloud-storage-common",
        description: "Library for integrating with GCS",
        link: "https://github.com/Lord-of-the-Repos/tps-cloud-storage-common"
    },
    {
        name: "tps-big-query-common",
        description: "Library for integrating with Big Query",
        link: "https://github.com/Lord-of-the-Repos/tps-big-query-common"
    },
    {
        name: "tps-notification-schema",
        description: "Avro schema files for sending events to the notification service",
        link: "https://github.com/Lord-of-the-Repos/tps-notification-schema"
    },
    {
        name: "tps-rebate-notification",
        description: "Service for sending notifications by email or teams messages",
        link: "https://github.com/Lord-of-the-Repos/tps-rebate-notification"
    },
    {
        name: "tps-rebate-arc-archiver",
        description: "Re-implemented kafka archiver with partitioned tables",
        link: "https://github.com/Lord-of-the-Repos/tps-rebate-arc-archiver"
    },
    {
        name: "tps-azure-auth-provider",
        description: "Provides Azure OAuth2 Authentication handlers for Confluent Cloud Kafka and Schema Registry",
        link: "https://github.com/Lord-of-the-Repos/tps-azure-auth-provider"
    }
]
