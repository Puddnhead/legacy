const environments = [
    {
        name: "tps-cpr-config-service",
        wiki: "https://confluence.primetherapeutics.com/display/REBATES/Config+Service",
        repoLink: "https://github.com/Lord-of-the-Repos/tps-cpr-config-service",
        environments: {
            dev: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-config-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-config-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/EfRrSTffcRBJ7KeZ9"
                    }
                ]
            },
            qa: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-config-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-config-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/iXAKJdfe23M8eXSE9",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-config-service/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            stage: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-config-service-stage.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-config-service-stage.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/EZPizYaZ3zXiskGL9",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-config-service/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            prod: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        logsLink: "https://cloudlogging.app.goo.gl/GFvExpwkoa5ME7nW9",
                        actuatorLink: "https://tps-cpr-config-service-prod.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-config-service-prod.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/"
                    }
                ]
            }
        }
    },
    {
        name: "tps-cpr-enrichment-service",
        wiki: "https://confluence.primetherapeutics.com/display/REBATES/Enrichment+Service",
        repoLink: "https://github.com/Lord-of-the-Repos/tps-cpr-enrichment-service",
        environments: {
            dev: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-enrichment-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-enrichment-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/87aur2pC4KTeW6XYA"
                    }
                ]
            },
            qa: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-enrichment-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-enrichment-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/ds8jtaUxDcmfbbJV8",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-enrichment-service/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            stage: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-enrichment-service-stage.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-enrichment-service-stage.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/j9Z4HPGhUbSccVWF9",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-enrichment-service/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            prod: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-enrichment-service-prod.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-enrichment-service-prod.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/Wmj8dnVgasSMC8Aa6"
                    }
                ]
            }
        }
    },
    {
        name: "tps-cpr-ingester-service",
        wiki: "https://confluence.primetherapeutics.com/display/REBATES/Ingester+Service",
        repoLink: "https://github.com/Lord-of-the-Repos/tps-cpr-ingester-service",
        environments: {
            dev: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-ingester-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-ingester-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/6igT7hMqSXGiYVWU8"
                    }
                ]
            },
            qa: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-ingester-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-ingester-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/STKqV8ppkgrRUXi19",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-ingester-service/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            stage: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-ingester-service-stage.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-ingester-service-stage.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/kUfChLcdbMVApZq97",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-ingester-service/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            prod: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-ingester-service-prod.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-ingester-service-prod.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/2Gp21ttKgJd3s8aH8"
                    }
                ]
            }
        }
    },
    {
        name: "tps-cpr-payment-service",
        wiki: "https://confluence.primetherapeutics.com/display/REBATES/Payment+Service",
        repoLink: "https://github.com/Lord-of-the-Repos/tps-cpr-payment-service",
        environments: {
            dev: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-payment-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-payment-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/CNNXXaPWwW6p8wCL8"
                    }
                ]
            },
            qa: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-payment-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-payment-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/bSaVHfkjaRn7GZLv5",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-payment-service/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            stage: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-payment-service-stage.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-payment-service-stage.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/UqobatN7ga52qdFa9",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-payment-service/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            prod: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-payment-service-prod.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-payment-service-prod.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/nGXahjPWLg1JMrvm7"
                    }
                ]
            }
        }
    },
    {
        name: "tps-cpr-report-service",
        wiki: "https://confluence.primetherapeutics.com/display/REBATES/Report+Service",
        repoLink: "https://github.com/Lord-of-the-Repos/tps-cpr-report-service",
        environments: {
            dev: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-report-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-report-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/rhB8NRuc2Y6sAT2x6"
                    }
                ]
            },
            qa: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-report-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-report-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/X9UMfqn48dV7pk227",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-report-service/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            stage: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-report-service-stage.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-report-service-stage.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/JiWJDcB5GRQGsJoeA",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-report-service/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            prod: {
                regions: [
                    {
                        name: "gke",
                        flywayHealthEnabled: true,
                        actuatorLink: "https://tps-cpr-report-service-prod.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-report-service-prod.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/c7MahRk3DQn5fYyi8"
                    }
                ]
            }
        }
    },
    {
        name: "tps-cpr-scheduler",
        wiki: "https://confluence.primetherapeutics.com/display/REBATES/Scheduler",
        repoLink: "https://github.com/Lord-of-the-Repos/tps-cpr-scheduler",
        environments: {
            dev: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-cpr-scheduler-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-scheduler-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/mhDBqSQtdnLWLLBp9"
                    }
                ]
            },
            qa: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-cpr-scheduler-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-scheduler-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/XwmuY6wc5HUwiDUx6",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-scheduler/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            stage: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-cpr-scheduler-stage.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-scheduler-stage.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/b7yCuyykFzitC8Kp7",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-scheduler/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            prod: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-cpr-scheduler-prod.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-scheduler-prod.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/tx6ttBTQaJDjxjCf9",
                    }
                ]
            }
        }
    },
    {
        name: "tps-cpr-kafka-archiver",
        wiki: "https://confluence.primetherapeutics.com/display/REBATES/Kafka+Archiver",
        repoLink: "https://github.com/Lord-of-the-Repos/tps-cpr-kafka-archiver",
        environments: {
            dev: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-cpr-kafka-archiver-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        logsLink: "https://cloudlogging.app.goo.gl/2NDSiQVYcxjqFqpQ7",
                        swaggerLink: "https://tps-cpr-kafka-archiver-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/"
                    }
                ]
            },
            qa: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-cpr-kafka-archiver-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        logsLink: "https://cloudlogging.app.goo.gl/ujrnbutj3Jm6NXHa7",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-kafka-archiver/actions/workflows/gke-deploy.yml",
                        swaggerLink: "https://tps-cpr-kafka-archiver-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/"
                    }
                ]
            },
            stage: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-cpr-kafka-archiver-stage.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-cpr-kafka-archiver-stage.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/pybhStJu2ZszMNAW6",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-cpr-kafka-archiver/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            prod: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-cpr-kafka-archiver-prod.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        logsLink: "https://cloudlogging.app.goo.gl/pqwKF2M2TETCLqbAA",
                        swaggerLink: "https://tps-cpr-kafka-archiver-prod.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/"
                    }
                ]
            }
        }
    },
    {
        name: "tps-rebate-notification",
        wiki: "https://confluence.primetherapeutics.com/display/REBATES/Rebate+Notification+Service",
        repoLink: "https://github.com/Lord-of-the-Repos/tps-rebate-notification",
        environments: {
            dev: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://rebate-notification-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://rebate-notification-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/vHRD6ZhBVUyT8bXA9"
                    }
                ]
            },
            qa: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://rebate-notification-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://rebate-notification-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-rebate-notification/actions/workflows/gke-deploy.yml",
                        logsLink: "https://cloudlogging.app.goo.gl/ubU5XLniCYSTuBJc8"
                    }
                ]
            },
            stage: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://rebate-notification-service-stage.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://rebate-notification-service-stage.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/vu8a7En8Watp2TeQ9",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-rebate-notification/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            prod: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://rebate-notification-service-prod.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://rebate-notification-service-prod.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/gaRBDnCYA6LU7gek6",
                    }
                ]
            }
        }
    },
    {
        name: "tps-rebate-arc-archiver",
        wiki: "https://confluence.primetherapeutics.com/spaces/REBATES/pages/672406107/Kafka+Archiver",
        repoLink: "https://github.com/Lord-of-the-Repos/tps-rebate-arc-archiver",
        environments: {
            dev: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-rebate-arc-archiver-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-rebate-arc-archiver-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/vXoZ3u5YuHTfR7kp9"
                    }
                ]
            },
            qa: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-rebate-arc-archiver-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-rebate-arc-archiver-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-rebate-arc-archiver/actions/workflows/gke-deploy.yml",
                        logsLink: "https://cloudlogging.app.goo.gl/WcAb3uBNWp4JGXWeA"
                    }
                ]
            },
            stage: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-rebate-arc-archiver-stage.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-rebate-arc-archiver-stage.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/qG2ugkMwR4Yai5wF9",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-rebate-arc-archiver/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            prod: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-rebate-arc-archiver-prod.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-rebate-arc-archiver-prod.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/AWf4aCeL9NZSn1DU8",
                    }
                ]
            }
        }
    },
    {
        name: "tps-primeone-claims-service",
        wiki: "https://confluence.primetherapeutics.com/spaces/REBATES/pages/936742793/Prime+One+Runout+Reporting",
        repoLink: "https://github.com/Lord-of-the-Repos/tps-primeone-claims-service",
        environments: {
            dev: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-primeone-claims-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-primeone-claims-service-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/sxdYKGPQgrr9muVD8"
                    }
                ]
            },
            qa: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-primeone-claims-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-primeone-claims-service-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/be57Ye1z5ME2bqpU9",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-primeone-claims-service/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            stage: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://tps-primeone-claims-service-stage.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-primeone-claims-service-stage.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/A5wSWePMVf1y2iDg7",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-primeone-claims-service/actions/workflows/gke-deploy.yml"
                    }
                ]
            },
            prod: {
                regions: [
                    {
                        name: "gke",
                        logsLink: "https://cloudlogging.app.goo.gl/J4dT6udepkgsmN6u9",
                        actuatorLink: "https://tps-primeone-claims-service-prod.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://tps-primeone-claims-service-prod.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/"
                    }
                ]
            }
        }
    },
    {
        name: "tps-primeone-drugiq-enrichment",
        wiki: "https://confluence.primetherapeutics.com/spaces/REBATES/pages/936742793/Prime+One+Runout+Reporting",
        repoLink: "https://github.com/Lord-of-the-Repos/tps-primeone-drugiq-enrichment",
        environments: {
            dev: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://primeone-drugiq-enrichment-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://primeone-drugiq-enrichment-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/xA12SBGpnt83ygAK6"
                    }
                ]
            },
            qa: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://primeone-drugiq-enrichment-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://primeone-drugiq-enrichment-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/4XTTUwDbbranDG8j8",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-primeone-drugiq-enrichment/actions/workflows/deploy-gke.yml"
                    }
                ]
            },
            stage: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://primeone-drugiq-enrichment-stage.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://primeone-drugiq-enrichment-stage.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/srYCDRy7n6yaDFt58",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-primeone-drugiq-enrichment/actions/workflows/deploy-gke.yml"
                    }
                ]
            },
            prod: {
                regions: [
                    {
                        name: "gke",
                        logsLink: "https://cloudlogging.app.goo.gl/ctiSCsBXgtEpekkk6",
                        actuatorLink: "https://primeone-drugiq-enrichment-prod.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://primeone-drugiq-enrichment-prod.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/"
                    }
                ]
            }
        }
    },

    {
        name: "tps-primeone-pharmacy-enrichment",
        wiki: "https://confluence.primetherapeutics.com/spaces/REBATES/pages/936742793/Prime+One+Runout+Reporting",
        repoLink: "https://github.com/Lord-of-the-Repos/tps-primeone-pharmacy-enrichment",
        environments: {
            dev: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://primeone-pharmacy-enrichment-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://primeone-pharmacy-enrichment-dev.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/aoE9rMc7HR2iF8Dj8"
                    }
                ]
            },
            qa: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://primeone-pharmacy-enrichment-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/actuator",
                        swaggerLink: "https://primeone-pharmacy-enrichment-qa.nonprod-prime-gke.nonprod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/fRzwXxWMhZ2dYZHz5",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-primeone-pharmacy-enrichment/actions/workflows/deploy-gke.yml"
                    }
                ]
            },
            stage: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://primeone-pharmacy-enrichment-stage.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://primeone-pharmacy-enrichment-stage.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/cPT34Tt9Lf4ktz5AA",
                        promotionLink: "https://github.com/Lord-of-the-Repos/tps-primeone-pharmacy-enrichment/actions/workflows/deploy-gke.yml"
                    }
                ]
            },
            prod: {
                regions: [
                    {
                        name: "gke",
                        actuatorLink: "https://primeone-pharmacy-enrichment-prod.prod-prime-gke.prod.gcp.primecx.net/actuator",
                        swaggerLink: "https://primeone-pharmacy-enrichment-prod.prod-prime-gke.prod.gcp.primecx.net/swagger-ui/index.html#/",
                        logsLink: "https://cloudlogging.app.goo.gl/Zo3HzXnNoCEYDbyH6"
                    }
                ]
            }
        }
    }
]
