const usefulLinks = [
    {
        name: "Connecting to Confluent Cloud Kafka Cluster",
        description: "Confluent Cloud Kafka Cluster Information",
        link: "https://confluence.primetherapeutics.com/display/DATASERVICES/Confluent+Cloud+Cluster+Information"
    },
    {
        name: "Kafka Topics",
        description: "Current Kafka Topics in each Environment",
        link: "https://confluence.primetherapeutics.com/display/REBATES/Trade+Kafka+Topics"
    },
    {
        name: "CPR Dev Team Confluence",
        description: "Root wiki for all the CPR confluence pages",
        link: "https://confluence.primetherapeutics.com/display/REBATES/CPR+Services"
    },
    {
        name: "CPR Product Confluence",
        description: "Documentation from the product side for CPR requirements",
        link: "https://confluence.primetherapeutics.com/x/0wXGIg"
    },
    {
        name: "Rebates Developer Links",
        description: "More useful links",
        link: "https://confluence.primetherapeutics.com/display/REBATES/Rebates+Developer+Links"
    },
    {
        name: "CP&R Insomnia Setup & Config",
        description: "Wiki on using Insomnia to hit CP&R resources directly",
        link: "https://confluence.primetherapeutics.com/display/REBATES/Insomnia+Setup"
    },
    {
        name: "GKE shared workflows",
        description: "GKE shared workflows",
        link: "https://github.com/Lord-of-the-Repos/tps-gke-workflows/tree/main/.github/workflows"
    },
    {
        name: "CPR All Production Errors",
        description: "Link concierge could use to find errors in all CPR services",
        link: "https://cloudlogging.app.goo.gl/PCKGmij2BhqrhFXD6"
    },
    {
        name: "Dependabot PRs",
        description: "PRs created by Dependabot",
        link: "https://github.com/pulls?q=is%3Aopen+is%3Apr+author%3Adependabot%5Bbot%5D+archived%3Afalse+user%3ALord-of-the-Repos+repository%3A+tps-cpr+"
    }
]
