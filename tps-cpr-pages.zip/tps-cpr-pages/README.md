# tps-cpr-pages
A Github Pages site for the CPR team

## Build Status
Build Status requires a Github Personal Access Token. Once provided, it will be stored as a cookie for a year.

### Github Access Token
Create a new classic access token https://github.com/settings/tokens with the following permissions:
* read:org
* repo
* workflow

#### Authorize Access Token
Use `Configure SSO` dropdown to authorize the access token with Lord-of-the-Repos org.