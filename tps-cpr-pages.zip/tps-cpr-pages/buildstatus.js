var workflowsByRepository = {}

function clearWorkflowsByRepository() {
    workflowsByRepository = {}
}

function getCachedRepositoryWorkflows(repository) {
    if (workflowsByRepository[repository] == null) {
        workflowsByRepository[repository] = new Map()
    }
    return workflowsByRepository[repository]
}

function captureRepositoryWorkflowInformation(repository, workflow) {
    let repositoryWorkflows = getCachedRepositoryWorkflows(repository)
    if (repositoryWorkflows.get(workflow.id) == null) {
        repositoryWorkflows.set(workflow.id, {workflow: workflow})
    }
}

function updatePullRequests(repository) {
    $.ajax({
        url: 'https://api.github.com/repos/Lord-of-the-Repos/' + repository + '/pulls?draft:false',
        headers: {
            'Authorization': 'Bearer ' + accessToken,
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28'
        },
        timeout: 10000, // fail the server-status request after 10 seconds
        cache: false,
        success: function (response) {
            let prs = response.filter((pr) => !pr.draft).length
            $(`#pulls-${repository}`).text(prs)
            console.log(repository + '/pulls: ' + prs)
        },
        error: function (request, response) {
           console.log(repository + '/pulls: failed: ' + response)
        }
    });
}

function getWorkflows(repository) {
    clearWorkflowsByRepository()

    $.ajax({
        url: 'https://api.github.com/repos/Lord-of-the-Repos/' + repository + '/actions/workflows',
        headers: {
            'Authorization': 'Bearer ' + accessToken,
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28'
        },
        timeout: 3000, // fail the server-status request after 3 seconds
        cache: true,
        success: function (response) {
            console.log('worfklow count: ' + response.total_count)
            response.workflows.forEach(workflow => {
                console.log("workflow: " + workflow.name, workflow.id)
                captureRepositoryWorkflowInformation(repository, workflow)
                console.log("cached workflows now at: " + getCachedRepositoryWorkflows(repository).size)
            })
            collectWorkflowRuns(repository)
        },
        error: function (request, response) {
            console.log('response failure: ' + response)
        }
    });
}

/**
 * stable: All of the most recent 5 runs have a conclusion of "success"
 * unstable: Any of the most recent 5 runs have a conclusion of "failure"
 * stale: The latest run is older than 7 days
 * running: The latest run is not yet completed
 * disabled: The workflow is disabled
 * @param workflowInformation
 */
function deduceAndCaptureStability(workflowInformation) {
    let runCount = workflowInformation.runs.length
    if (runCount < 5) {
        console.log('not enough runs to determine stability')
        workflowInformation['stability'] = 'stale'
        return
    }
    let recentRuns = workflowInformation.runs.slice(0, 5)
    workflowInformation['last-run'] = recentRuns[0].created_at
    if (workflowInformation.workflow.state === 'disabled_manually') {
        workflowInformation['stability'] = 'disabled'
        return
    }
    if (recentRuns[0].status !== 'completed') {
        console.log('workflowInformation: ' + workflowInformation.workflow.name + ', not completed')
        workflowInformation['stability'] = 'running'
        return
    }
    if (recentRuns[0].conclusion === 'failure') {
        console.log('workflowInformation: ' + workflowInformation.workflow.name + ', not completed')
        workflowInformation['stability'] = 'broken'
        return
    }
    if (new Date(recentRuns[0].created_at) < Date.now() - 7 * 24 * 60 * 60 * 1000) {
        console.log('workflowInformation: ' + workflowInformation.workflow.name + ', stale')
        workflowInformation['stability'] = 'stale'
        return
    }
    let failedRuns = recentRuns.filter(run => run.status === 'completed' && run.conclusion === 'failure')
    let failedRunCount = failedRuns.length
    let stability = 'stable'
    if (failedRunCount > 0) {
        stability = 'unstable'
    }
    console.log('workflowInformation: ' + workflowInformation.workflow.name + ', stability: ' + stability)
    workflowInformation['stability'] = stability
}

function workflowInformationRunsReplacer(key, value) {
    if (key === 'runs') {
        return []
    }
    return value
}

function analyzeWorkflows(repository) {
    let repositoryWorkflows = getCachedRepositoryWorkflows(repository)
    for (const workflowId of repositoryWorkflows.keys()) {
        let workflowInformation = repositoryWorkflows.get(workflowId)
        console.log('analyzing workflow: ' + workflowInformation.workflow.name)
        let runCount = workflowInformation.runs.length
        let failedRuns = workflowInformation.runs.filter(run => run.status === 'completed' && run.conclusion === 'failure')
        let failedRunCount = failedRuns.length
        console.log('workflowInformation: ' + workflowInformation.workflow.name + ', run count: ' + runCount + ', failed run count: ' + failedRunCount)
        deduceAndCaptureStability(workflowInformation)
        console.log('workflowInformation: ' + JSON.stringify(workflowInformation, workflowInformationRunsReplacer, 2))
    }
}

function collectWorkflowRuns(repository) {
    var repositoryWorkflows = getCachedRepositoryWorkflows(repository)
    for (const workflowId of repositoryWorkflows.keys()) {
        console.log('fetching runs for workflow: ' + workflowId)
        let workflowInformation = repositoryWorkflows.get(workflowId)
        console.log('found workflow: ' + workflowInformation.workflow.name)
        workflowInformation['runs'] = []
        $.ajax({
            url: 'https://api.github.com/repos/Lord-of-the-Repos/' + repository + '/actions/workflows/' + workflowId + '/runs',
            headers: {
                'Authorization': 'Bearer ' + accessToken,
                'Accept': 'application/vnd.github+json',
                'X-GitHub-Api-Version': '2022-11-28'
            },
            timeout: 3000,
            cache: true,
            success: function (response) {
                console.log('workflow run TOTAL count: ' + response.total_count)
                response.workflow_runs.forEach(run => {
                    console.log("workflow run: " + run.id, run.status, run.conclusion, run.created_at)
                    workflowInformation['runs'].push(run)
                })
                console.log('workflow runs now at: ' + workflowInformation['runs'].length)
                analyzeWorkflows(repository)
                renderWorkflowReport(repository)
            },
            error: function (request, response) {
                console.log('response failure: ' + response)
            }
        });
    }
}

function renderWorkflowReport(repository) {
    let workflows = getCachedRepositoryWorkflows(repository)
    const reportTable = $(`#workflow-report-for-${repository}`)
    reportTable.empty()
    for (const workflowInformation of workflows.values()) {
        const tr = $(`<tr></tr>`)
        const td = $(`<td></td>`)
        const workflowFile = workflowInformation.workflow.path.replace('.github/workflows/', '')
        const url = `https://github.com/Lord-of-the-Repos/${repository}/actions/workflows/${workflowFile}`
        const div = $(`<div class="region-div workflow-stability-${workflowInformation.stability}"></div>`)
        const href = $(`<a href="${url}" target="_blank" title="${workflowInformation.stability}">${workflowInformation.workflow.name}</a>`)

        div.append(href)
        td.append(div)
        tr.append(td)
        reportTable.append(tr)
    }

}

function renderRepositories(repository) {
    const headerRow = $("#repositories-table-header-row")
    const repositoryHeaderCell =
        $(`<th class="environments-table-cell">${repository}<div><a href="https://github.com/Lord-of-the-Repos/${repository}/pulls" target="_blank"><span id="pulls-${repository}">0</span></a></div></th>`)
    headerRow.append(repositoryHeaderCell)

    const bodyRow = $("#repositories-table-body-row")
    const repositoryBodyCell =
        $(`<td style="vertical-align: top;"></td>`)
    const repositoryWorkflowReportTable =
        $(`<table class="repositoryTable"><tbody id="workflow-report-for-${repository}"></tbody></table>`)
    repositoryBodyCell.append(repositoryWorkflowReportTable)
    bodyRow.append(repositoryBodyCell)
}
