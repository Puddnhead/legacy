const USERNAME_COOKIE = 'username'
const USERNAME_COOKIE_EXPIRES_DAYS = 30
const GH_TOKEN_COOKIE = 'ghToken'
const GH_TOKEN_COOKIE_EXPIRES_DAYS = 365
let clientName = getCookie(USERNAME_COOKIE)
let accessToken = getCookie(GH_TOKEN_COOKIE)
let hasFocus = true

/**
 * Creates the environments table with a row per entry in environments.js.
 */
function createEnvironmentsTable() {
    const table = $("#environments-table")

    environments.forEach(application => {
        const rowId = getRowId(application)
        const row = $(`<tr id='${rowId}' class='environments-row'></tr>`)

        const devId = getCompositeId(application.name, "dev")
        const qaId = getCompositeId(application.name, "qa")
        const stageId = getCompositeId(application.name, "stage")
        const prodId = getCompositeId(application.name, "prod")

        const applicationCell = buildApplicationCell(application)
        const devCell =
            $(`<td id='${devId}' class='environments-cell'></td>`)
        if (application.environments.dev) {
            buildEnvironmentCell(devCell, devId, application.environments.dev)
        }

        const qaCell =
            $(`<td id='${qaId}' class='environments-cell'></td>`)
        if (application.environments.qa) {
            buildEnvironmentCell(qaCell, qaId, application.environments.qa)
        }

        const stageCell =
            $(`<td id='${stageId}' class='environments-cell'></td>`)
        if (application.environments.stage) {
            buildEnvironmentCell(stageCell, stageId, application.environments.stage)
        }

        const prodCell =
            $(`<td id='${prodId}' class='environments-cell'></td>`)
        if (application.environments.prod) {
            buildEnvironmentCell(prodCell, prodId, application.environments.prod)
        }

        row.append(applicationCell)
        row.append(devCell)
        row.append(qaCell)
        row.append(stageCell)
        row.append(prodCell)

        table.append(row)
    })
}

function buildApplicationCell(application) {
    const applicationId = getApplicationId(application);
    let cell = $(`<td id='${applicationId}' class='environments-cell'></td>`)
    cell.append($(`<a href='${application.repoLink}' target='_blank'=>${application.name}</a>`))
    if(application.subtitle) {
        cell.append($(`<div class=subtitle>${application.subtitle}</div>`))
    }
    if(application.wiki) {
        cell.append($(`<div><a href="${application.wiki}" target="_blank" title='wiki'><img class='wiki' src="images/book.png"/></a></div>`))
    }
    return cell
}

const diffSvg = '<svg aria-hidden="true" height="25" viewBox="0 0 16 16" version="1.1" width="25" data-view-component="true"><path d="M1 1.75C1 .784 1.784 0 2.75 0h7.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0 1 13.25 16H2.75A1.75 1.75 0 0 1 1 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25h10.5a.25.25 0 0 0 .25-.25V4.664a.25.25 0 0 0-.073-.177l-2.914-2.914a.25.25 0 0 0-.177-.073ZM8 3.25a.75.75 0 0 1 .75.75v1.5h1.5a.75.75 0 0 1 0 1.5h-1.5v1.5a.75.75 0 0 1-1.5 0V7h-1.5a.75.75 0 0 1 0-1.5h1.5V4A.75.75 0 0 1 8 3.25Zm-3 8a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75Z"></path></svg>'

function buildEnvironmentCell(environmentCell, environmentCellId, environmentData) {
    environmentData.regions.forEach(region => {
        const regionDivId = getCompositeId(environmentCellId, region.name)
        const regionDiv = $(`<div id='${regionDivId}' class='region-div'></div>`)
        if (region.actuatorLink) {
            const healthLinkId = getHealthLinkId(regionDivId)
            const healthLink = $(`<a id='${healthLinkId}' href='${region.actuatorLink}/health' class='regional-link' target="_blank">${region.name}</a>`)
            regionDiv.append(healthLink)
        }
        if (region.logsLink) {
            const logsIcon = $(`<a href='${region.logsLink}' target='_blank'><img src='images/logs.png' title='Logs' class='regional-icon-image' /></a>`)
            regionDiv.append(logsIcon)
        }
        if (region.swaggerLink) {
            const swaggerIcon = $(`<a href='${region.swaggerLink}' target='_blank'><img src='images/swagger.png' title='Swagger API Specs' class='regional-icon-image' /></a>`)
            regionDiv.append(swaggerIcon)
        }
        if (region.flywayHealthEnabled) {
            const flywayHealthLinkId = getFlywayHealthLinkId(regionDivId)
            const flywayHealthLink = $(`<a id='${flywayHealthLinkId}' href='${region.actuatorLink}/health/flyway' class='regional-link' target="_blank"><img src='images/flyway.png' title='Flyway status' class='regional-icon-image' /><span id="status" class='regional-span'></span></a>`)
            regionDiv.append(flywayHealthLink)
        }
        if (region.promotionLink) {
            const promotionLink =
                $(`<a href='${region.promotionLink}' target='_blank' class='regional-link'><img src='images/right_arrow.png' class='regional-icon-image promote' title="Promote"></a>"`)
            regionDiv.append(promotionLink)

            const diffLinkId = getDiffLinkId(regionDivId)
            const diffIcon = $(`<a id='${diffLinkId}' href="" target="_blank">${diffSvg}</a>`)
            regionDiv.append(diffIcon)
        }
        environmentCell.append(regionDiv)
    })
}

/**
 * Creates the repositories table with a row per entry in repositories.js
 */
function createRepoTable() {
    const repoTable = $("#repo-table")

    repositories.sort((a, b) => {
	const nameA = a.name.toUpperCase()
	const nameB = b.name.toUpperCase()
	if (nameA < nameB) {
		return -1
	}
        if (nameA > nameB) {
            return 1
        }
        return 0
    }).forEach(repo => {
        const row = $(`<tr class='repo-row'></tr>`)

        const repository =
            $(`<td class='repo-cell'><a class='repo-link' href='${repo.link}' target='_blank'>${repo.name}</a></td>`)
        const description =
            $(`<td class='repo-cell'>${repo.description}</td>`)
        row.append(repository)
        row.append(description)
        repoTable.append(row)
    })
}

/**
 * Creates the useful links table with a row per entry in useful-links.js
 */
function createUsefulLinksTable() {
    const usefulLinksTable = $("#useful-links-table")

    usefulLinks.forEach(usefulLink => {
        const row = $(`<tr class='useful-links-row'></tr>`)

        const nameCell =
            $(`<td class='useful-links-cell'><a class='useful-links-link' href='${usefulLink.link}' target='_blank'>${usefulLink.name}</a></td>`)
        const descriptionCell =
            $(`<td class='useful-links-cell'>${usefulLink.description}</td>`)
        row.append(nameCell)
        row.append(descriptionCell)
        usefulLinksTable.append(row)
    })
}

function createBuildStatusTable() {
    if (accessToken.length > 0) {
        $(`#enter-ghtoken-div`).hide()
        const headerRow = $("#repositories-table-header-row")
        headerRow.empty()
        const bodyRow = $("#repositories-table-body-row")
        bodyRow.empty()

        build_repositories.forEach(repo => {
            renderRepositories(repo)
            getWorkflows(repo)
            updatePullRequests(repo)
        })
    } else {
        $(`#enter-ghtoken-div`).show()
        registerTokenListeners()
    }
}

/**
 * Call each environment's server-status endpoint and update the class on the row for that environment accordingly. CSS
 * rules use the class to highlight healthy and unhealthy environments.
 */
function updateServerStatuses(isInitialPageLoad, isManualReload) {
    // only fetch statuses environments tab is open or we haven't called this method yet
    const environmentsTable = $("#environments-table")
    if (hasFocus && (isInitialPageLoad || environmentsTable.parent().css("display") != "none")) {
        environments.forEach(application => {
            if (application.environments.dev) {
                const devId = getCompositeId(application.name, "dev")
                updateServerHealth(devId, application.environments.dev)
            }
            if (application.environments.qa) {
                const qaId = getCompositeId(application.name, "qa")
                updateServerHealth(qaId, application.environments.qa)
            }
            if (application.environments.stage) {
                const stageId = getCompositeId(application.name, "stage")
                updateServerHealth(stageId, application.environments.stage)
            }
            if (application.environments.prod) {
                const prodId = getCompositeId(application.name, "prod")
                updateServerHealth(prodId, application.environments.prod)
            }
        });
    }

    setTimeout(checkVersionMismatch, 5000)

    if (!isManualReload) {
        // reschedule for 30 seconds later
        setTimeout(updateServerStatuses, 30000)
    }
}

function checkVersionMismatch() {

    environments.forEach(application => {
        checkApplicationVersionMismatch(application, "qa", "stage")
        checkApplicationVersionMismatch(application, "stage", "prod")
    });
}

function checkApplicationVersionMismatch(application, sourceEnvName, destinationEnvName) {

    const applicationName = application.name
    const sourceEnv = application.environments[sourceEnvName]
    const destinationEnv = application.environments[destinationEnvName]

    sourceEnv.regions.forEach(region => {
        const sourceVersion = region.version
        const destinationRegion = destinationEnv.regions.find((element) => element.name == region.name)
        const destinationVersion = destinationRegion?.version
        const promoteRequired = (sourceVersion && destinationVersion && sourceVersion != destinationVersion)
        const sourceEnvCellId = getCompositeId(applicationName, sourceEnvName)
        const regionDivId = getCompositeId(sourceEnvCellId, region.name)
        updatePromoteStatus(regionDivId, promoteRequired)
        const diffLinkId = getDiffLinkId(regionDivId)
        updateDiffLink(diffLinkId, application.repoLink, sourceVersion, destinationVersion)
    });
}

function updateServerHealth(environmentCellId, environmentData) {
    environmentData.regions.forEach(region => {
        if (!region.actuatorLink) {
            return
        }
        const regionDivId = getCompositeId(environmentCellId, region.name)
        $.ajax({
            url: region.actuatorLink + '/health',
            data: {
                "clientName": clientName
            },
            timeout: 5000, // fail the server-status request after 5 seconds
            cache: false,
            success: function () {
                updateEnvironmentStatus(regionDivId, true)
            },
            error: function (xhr) {
                updateEnvironmentStatus(regionDivId, false)
            }
        });
        updateAppVersion(region, environmentCellId)
        updateFlywayStatus(region, environmentCellId)
    })
}

function updateAppVersion(region, environmentCellId) {
    if (!region.actuatorLink) {
        return
    }
    const regionDivId = getCompositeId(environmentCellId, region.name)
    const healthLinkId = getHealthLinkId(regionDivId)
    $.ajax({
        url: region.actuatorLink + '/info',
        data: {
            "clientName": clientName
        },
        timeout: 10000, // fail the server-status request after 10 seconds
        cache: false,
        success: function (response) {
            let version = 'unknown version'
            if (response.build) {
                version = response.build.version
            }
            region.version = version
            $(`#${healthLinkId}`).text(version)
        },
        error: function (request, response) {
            $(`#${healthLinkId}`).text(region.name)
        }
    });
}

function updateFlywayStatus(region, environmentCellId) {
    if (!region.actuatorLink || !region.flywayHealthEnabled) {
        return
    }
    const regionDivId = getCompositeId(environmentCellId, region.name)
    const flywayHealthLinkId = getFlywayHealthLinkId(regionDivId)
    $.ajax({
        url: region.actuatorLink + '/health/flyway',
        data: {
            "clientName": clientName
        },
        timeout: 10000, // fail the server-status request after 10 seconds
        cache: false,
        success: function (response) {
            let flywayStatus = ''
            if (response.details) {
                if (response.details.behind.length != 0) {
                    flywayStatus = ' \u21E9'
                }
                if (response.details.ahead.length != 0) {
                    flywayStatus = ' \u21E7'
                }
            }
            $(`#${flywayHealthLinkId}`).find("#status").text(flywayStatus)
            $(`#${flywayHealthLinkId}`).find('img').removeClass('server-unhealthy')
            $(`#${flywayHealthLinkId}`).find('img').addClass('server-healthy')
        },
        error: function (request, response) {
           $(`#${flywayHealthLinkId}`).find('img').removeClass('server-healthy')
           $(`#${flywayHealthLinkId}`).find('img').addClass('server-unhealthy')
        }
    });
}

function updateEnvironmentStatus(environmentId, success) {
    const environmentElement = $(`#${environmentId}`)
   if (success) {
       environmentElement.removeClass('server-unhealthy')
       environmentElement.addClass('server-healthy')
   } else {
       environmentElement.removeClass('server-healthy')
       environmentElement.addClass('server-unhealthy')
    }
}

function updateDiffLink(diffLinkId, repoLink, sourceVersion, destinationVersion) {
    const diffLink = $(`#${diffLinkId}`)
    if (sourceVersion === destinationVersion) {
        diffLink.hide()
    } else {
        const url = `${repoLink}/compare/v${destinationVersion}...v${sourceVersion}`
        diffLink.attr('href', url)
        diffLink.show()
    }
}
function updatePromoteStatus(regionDivId, required) {
    const image = $(`#${regionDivId}`).find('.promote')
    if (required) {
        image.addClass('promote-required')
    } else {
        image.removeClass('promote-required')
   }
}

function getCompositeId(baseId, appender) {
    return baseId + "-" + appender
}

function getRowId(environment) {
    return getCompositeId(environment.name, "row")
}

function getApplicationId(application) {
    return getCompositeId(application.name, "application")
}

function getHealthLinkId(regionDivId) {
    return getCompositeId(regionDivId, "health-link")
}

function getFlywayHealthLinkId(regionDivId) {
    return getCompositeId(regionDivId, "flyway-health-link")
}
function getDiffLinkId(regionDivId) {
    return getCompositeId(regionDivId, "diff-link")
}

/**
 * Build the server status table and begin polling for statuses
 */
function loadDashboard() {
    createEnvironmentsTable()
    updateServerStatuses(true, false)
    createRepoTable()
    createUsefulLinksTable()
    createBuildStatusTable()
}

function handleNameSubmit() {
    const nameText = $(`#name-input`).val()

    // require that user enters a name
    if (!nameText) {
        return
    }

    // remove white space
    clientName = nameText.replace(/\s/g, "")
    setCookie(USERNAME_COOKIE, clientName, USERNAME_COOKIE_EXPIRES_DAYS)

    showDashboard()
}

function handleGHTokenSubmit() {
    const ghToken = $(`#ghtoken-input`).val()

    // require that user enters a name
    if (!ghToken) {
        return
    }

    setCookie(GH_TOKEN_COOKIE, ghToken, GH_TOKEN_COOKIE_EXPIRES_DAYS)
    accessToken = ghToken
    createBuildStatusTable()
}

function showDashboard() {
    loadDashboard()
    $(`#enter-name-div`).hide()
    $(`#main-dashboard-div`).show()
}

function registerNameListeners() {
    $(`#name-submit`).on("click", handleNameSubmit)
    $('#name-input').on('keypress', (e) => {
        if( e.which === 13){
            handleNameSubmit()
        }
    });
}

function registerTokenListeners() {
    $(`#ghtoken-submit`).on("click", handleGHTokenSubmit)
    $('#ghtoken-input').on('keypress', (e) => {
        if( e.which === 13){
            handleGHTokenSubmit()
        }
    });
}

function setCookie(cookieName, cookieValue, expireInDays) {
    const d = new Date();
    d.setTime(d.getTime() + (expireInDays*24*60*60*1000));
    let expires = "expires="+ d.toUTCString();
    document.cookie = cookieName + "=" + cookieValue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) === 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

document.addEventListener("visibilitychange", function (event) {
    if (document.hidden) {
        hasFocus = false
        console.log('lost focus')
    } else {
        hasFocus = true
        console.log('gained focus')
    }
});

$(function () {
    if(clientName.length > 0) {
        showDashboard()
    } else {
        registerNameListeners()
    }
})
