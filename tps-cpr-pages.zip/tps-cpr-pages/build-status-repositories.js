var build_repositories = [
    'tps-cpr-config-service',
    'tps-cpr-enrichment-service',
    'tps-cpr-ingester-service',
    'tps-cpr-payment-service',
    'tps-cpr-report-service',
    'tps-cpr-scheduler',
    'tps-cpr-kafka-archiver',
    'tps-rebate-notification',
    'tps-cpr-claim-data',
    'tps-rebate-cpr-schemas'
]
